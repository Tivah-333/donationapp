import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart'; // For date formatting

class DonorsDonationHistoryPage extends StatefulWidget {
  const DonorsDonationHistoryPage({super.key});

  @override
  State<DonorsDonationHistoryPage> createState() => _DonorsDonationHistoryPageState();
}

class _DonorsDonationHistoryPageState extends State<DonorsDonationHistoryPage> {
  List<Map<String, dynamic>> donations = [];
  bool isLoading = true;

  // Badges (unchanged structure, but with better icon handling)
  final List<Map<String, dynamic>> badges = [
    {
      'name': 'Bronze Donor',
      'description': 'Donated at least 3 times',
      'earned': false,
      'icon': Icons.emoji_events,
      'threshold': 3,
    },
    {
      'name': 'Silver Donor',
      'description': 'Donated at least 10 times',
      'earned': false,
      'icon': Icons.emoji_events_outlined,
      'threshold': 10,
    },
    {
      'name': 'Gold Donor',
      'description': 'Donated at least 20 times',
      'earned': false,
      'icon': Icons.workspace_premium_outlined,
      'threshold': 20,
    },
  ];

  @override
  void initState() {
    super.initState();
    _loadDonations();
  }

  Future<void> _loadDonations() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('You must be logged in to view donations')),
        );
        setState(() => isLoading = false);
      }
      return;
    }

    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('donations')
          .where('userId', isEqualTo: user.uid)
          .orderBy('timestamp', descending: true)
          .get();

      final fetchedDonations = snapshot.docs.map((doc) {
        final data = doc.data();
        final Timestamp? ts = data['timestamp'] as Timestamp?;
        final dateStr = ts != null
            ? DateFormat('MMM dd, yyyy').format(ts.toDate())
            : 'Unknown';

        // Handle quantity (int or string)
        final quantityDynamic = data['quantity'];
        int quantity = 0;
        if (quantityDynamic is int) {
          quantity = quantityDynamic;
        } else if (quantityDynamic is String) {
          quantity = int.tryParse(quantityDynamic) ?? 0;
        }

        return {
          'date': dateStr,
          'category': data['category'] ?? 'Unknown',
          'quantity': quantity,
          'status': data['status'] ?? 'Pending',
        };
      }).toList();

      // Update badge earned status
      final donationCount = fetchedDonations.length;
      for (var badge in badges) {
        badge['earned'] = donationCount >= badge['threshold'];
      }

      if (mounted) {
        setState(() {
          donations = fetchedDonations;
          isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load donations: $e')),
        );
        setState(() => isLoading = false);
      }
    }
  }

  Map<String, int> getDonationTotals() {
    final Map<String, int> totals = {};
    for (var donation in donations) {
      final category = donation['category'] as String;
      final quantity = donation['quantity'] as int;
      totals[category] = (totals[category] ?? 0) + quantity;
    }
    return totals;
  }

  @override
  Widget build(BuildContext context) {
    final totals = getDonationTotals();

    return Scaffold(
      appBar: AppBar(title: const Text('Donation History')),
      body: isLoading
          ? _buildLoadingSkeleton() // Better than just a spinner
          : RefreshIndicator( // Pull-to-refresh support
        onRefresh: _loadDonations,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              _buildBadgesSection(),
              const SizedBox(height: 24),
              _buildStatisticsSection(totals),
              const SizedBox(height: 24),
              _buildDonationsList(),
            ],
          ),
        ),
      ),
    );
  }

  // Loading skeleton (better UX)
  Widget _buildLoadingSkeleton() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: 5,
      itemBuilder: (_, i) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Row(
          children: [
            const CircleAvatar(backgroundColor: Colors.grey, radius: 24),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 16,
                    width: 150,
                    color: Colors.grey[300],
                  ),
                  const SizedBox(height: 8),
                  Container(
                    height: 12,
                    width: 200,
                    color: Colors.grey[300],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatisticsSection(Map<String, int> totals) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Donation Statistics',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        ...totals.entries.map((entry) => Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Text(
            '${entry.key}: ${entry.value} items donated',
            style: const TextStyle(fontSize: 16),
          ),
        )),
      ],
    );
  }

  Widget _buildBadgesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Your Badges',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 100,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: badges.length,
            separatorBuilder: (_, __) => const SizedBox(width: 16),
            itemBuilder: (context, index) {
              final badge = badges[index];
              return Column(
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: badge['earned'] ? Colors.amber : Colors.grey[300],
                    child: Icon(
                      badge['icon'],
                      size: 36,
                      color: badge['earned'] ? Colors.white : Colors.grey[600],
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: 100,
                    child: Text(
                      badge['name'],
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: badge['earned'] ? Colors.black : Colors.grey,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildDonationsList() {
    if (donations.isEmpty) {
      return const Center(
        child: Text('No donations found.'),
      );
    }

    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(), // For nested scrolling
      shrinkWrap: true,
      itemCount: donations.length,
      separatorBuilder: (_, __) => const Divider(height: 16),
      itemBuilder: (context, index) {
        final donation = donations[index];
        return ListTile(
          leading: const Icon(Icons.card_giftcard, color: Colors.blue),
          title: Text(
            '${donation['category']} — Quantity: ${donation['quantity']}',
            style: const TextStyle(fontWeight: FontWeight.w500),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Date: ${donation['date']}'),
              const SizedBox(height: 4),
              Text(
                'Status: ${donation['status']}',
                style: TextStyle(
                  color: donation['status'] == 'Completed'
                      ? Colors.green
                      : Colors.orange,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}