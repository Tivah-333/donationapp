import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'login_screen.dart';
import 'signup_screen.dart';
import 'donor_home.dart';
import 'organization_home.dart';
import 'admin_home.dart';
import 'manage_users.dart';
import 'manage_donations.dart';
import 'welcome_screen.dart';
import 'view_reports.dart';
import 'org_status_screen.dart';
import 'admin_org_approval.dart';
import 'admin_settings.dart';
import 'admin_issue_reports.dart';
import 'admin_notifications.dart';
import 'admin_profile_page.dart';
import 'donation_statistics_page.dart';
import 'create_donation_request.dart';
import 'organization_settings.dart';
import 'report_problem_page.dart';
import 'org_contact_support_page.dart';
import 'org_notifications.dart';
import 'make_donation.dart';
import 'donors_donation_history.dart';
import 'donor_notification_setting.dart';
import 'donor_contact_support_page.dart';
import 'donor_report_problem_page.dart';
import 'donor_settings.dart';
import 'donor_profile.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  print('🔔 BG Message: ${message.messageId}');
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  // Set up background message handler
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  runApp(const CharityBridgeApp());
}

class CharityBridgeApp extends StatefulWidget {
  const CharityBridgeApp({super.key});

  @override
  State<CharityBridgeApp> createState() => _CharityBridgeAppState();
}

class _CharityBridgeAppState extends State<CharityBridgeApp> {
  bool isDarkMode = false;

  @override
  void initState() {
    super.initState();
    _setupFCM();
  }

  void toggleDarkMode(bool value) {
    setState(() {
      isDarkMode = value;
    });
  }

  Future<void> _setupFCM() async {
    FirebaseMessaging messaging = FirebaseMessaging.instance;

    // Request permissions for iOS (has no effect on Android)
    await messaging.requestPermission();

    // Get the token
    String? token = await messaging.getToken();
    print('📱 FCM Token: $token');

    // Save token to Firestore if user is logged in
    final user = FirebaseAuth.instance.currentUser;
    if (user != null && token != null) {
      await FirebaseFirestore.instance.collection('users').doc(user.uid).update({
        'fcmToken': token,
      });
      print('✅ Token saved to Firestore');
    }

    // Handle foreground messages
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      if (message.notification != null) {
        print('📩 Notification: ${message.notification!.title} - ${message.notification!.body}');
        // Optional: show a dialog/snackbar here
      }
    });

    // App opened from terminated state
    FirebaseMessaging.instance.getInitialMessage().then((message) {
      if (message != null) {
        print('📦 App launched by notification: ${message.notification?.title}');
      }
    });

    // App opened from background
    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      print('📦 App resumed by notification tap: ${message.notification?.title}');
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Charity Bridge',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple, brightness: Brightness.light),
        useMaterial3: true,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple, brightness: Brightness.dark),
        useMaterial3: true,
        brightness: Brightness.dark,
      ),
      themeMode: isDarkMode ? ThemeMode.dark : ThemeMode.light,
      initialRoute: '/',
      routes: {
        '/': (context) => const AuthWrapper(),
        '/welcome': (context) => const WelcomeScreen(),
        '/login': (context) => const LoginScreen(),
        '/signup': (context) => const SignupScreen(),
        '/donor': (context) => const DonorHome(),
        '/organization': (context) => const OrganizationHome(),
        '/admin': (context) => const AdminHome(),
        '/manageUsers': (context) => const ManageUsersPage(),
        '/manageDonations': (context) => const ManageDonations(),
        '/viewReports': (context) => const ViewReportsPage(),
        '/orgStatus': (context) => const OrgStatusScreen(status: 'pending'),
        '/admin/org-approvals': (context) => const AdminOrgApprovalDashboard(),
        '/admin/settings': (context) => AdminSettingsPage(
          isDarkMode: isDarkMode,
          onDarkModeChanged: toggleDarkMode,
        ),
        '/admin/notifications': (context) => const AdminNotificationsPage(),
        '/admin/issue-reports': (context) => const AdminIssueReportsPage(),
        '/admin/profile': (context) => const AdminProfilePage(),
        '/organization/statistics': (context) => const DonationStatisticsPage(),
        '/createRequest': (context) => const CreateDonationRequestPage(),
        '/organization/settings': (context) => const OrganizationSettingsPage(),
        '/reportProblem': (context) => const ReportProblemPage(),
        '/contactSupport': (context) => const OrgContactSupportPage(),
        '/organization/notifications': (context) => const OrgNotificationsPage(),
        '/donate': (context) => const MakeDonationPage(),
        '/donor/history': (context) => const DonorsDonationHistoryPage(),
        '/donor/notifications': (context) => const DonorNotificationPage(),
        '/donor/support': (context) => const DonorContactSupportPage(),
        '/donor/report': (context) => const DonorReportProblemPage(),
        '/donor/settings': (context) => const DonorSettingsPage(),
        '/donor/profile': (context) => const DonarProfile(),
      },
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }

        final user = snapshot.data;
        if (user == null) return const WelcomeScreen();

        return FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance.collection('users').doc(user.uid).get(),
          builder: (context, roleSnapshot) {
            if (roleSnapshot.connectionState == ConnectionState.waiting) {
              return const Scaffold(body: Center(child: CircularProgressIndicator()));
            }

            if (!roleSnapshot.hasData || !roleSnapshot.data!.exists) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                FirebaseAuth.instance.signOut();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('User data not found.')),
                );
              });
              return const LoginScreen();
            }

            final data = roleSnapshot.data!.data() as Map<String, dynamic>?;
            final role = data?['role'] as String?;
            final status = data?['status'] as String? ?? 'approved';

            switch (role) {
              case 'Donor':
                return const DonorHome();
              case 'Organization':
                if (status == 'pending' || status == 'rejected') {
                  return OrgStatusScreen(status: status);
                }
                return const OrganizationHome();
              case 'Administrator':
                return const AdminHome();
              default:
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  FirebaseAuth.instance.signOut();
                });
                return const LoginScreen();
            }
          },
        );
      },
    );
  }
}
