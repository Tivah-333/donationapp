import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DonorNotificationPage extends StatefulWidget {
  const DonorNotificationPage({super.key});

  @override
  State<DonorNotificationPage> createState() => _DonorNotificationPageState();
}

class _DonorNotificationPageState extends State<DonorNotificationPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  bool _notificationsEnabled = true;
  bool _isLoading = true;
  final List<Map<String, dynamic>> _notifications = [];

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _loadNotifications();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
      _isLoading = false;
    });
  }

  Future<void> _loadNotifications() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final snapshot = await _firestore
        .collection('notifications')
        .doc(user.uid)
        .collection('userNotifications')
        .orderBy('timestamp', descending: true)
        .limit(20)
        .get();

    setState(() {
      _notifications.clear();
      _notifications.addAll(snapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'title': data['title'] ?? 'Notification',
          'body': data['body'] ?? '',
          'timestamp': data['timestamp']?.toDate() ?? DateTime.now(),
          'read': data['read'] ?? false,
        };
      }));
    });
  }

  Future<void> _toggleNotifications(bool value) async {
    setState(() => _notificationsEnabled = value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications_enabled', value);

    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      await _firestore.collection('userSettings').doc(user.uid).set({
        'notificationsEnabled': value,
        'lastUpdated': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    }
  }

  Future<void> _markAsRead(String notificationId) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    await _firestore
        .collection('notifications')
        .doc(user.uid)
        .collection('userNotifications')
        .doc(notificationId)
        .update({'read': true});

    setState(() {
      final index = _notifications.indexWhere((n) => n['id'] == notificationId);
      if (index != -1) {
        _notifications[index]['read'] = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
        children: [
          SwitchListTile(
            title: const Text('Enable Notifications'),
            value: _notificationsEnabled,
            onChanged: _toggleNotifications,
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView.builder(
              itemCount: _notifications.length,
              itemBuilder: (context, index) {
                final notification = _notifications[index];
                return Dismissible(
                  key: Key(notification['id']),
                  background: Container(color: Colors.red),
                  onDismissed: (_) => _markAsRead(notification['id']),
                  child: InkWell(
                    onTap: () => _markAsRead(notification['id']),
                    child: Container(
                      color: notification['read']
                          ? Colors.grey[100]
                          : Colors.grey[300],
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            notification['title'],
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: notification['read']
                                  ? Colors.grey[600]
                                  : Colors.black,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            notification['body'],
                            style: TextStyle(
                              color: notification['read']
                                  ? Colors.grey[500]
                                  : Colors.grey[700],
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _formatDate(notification['timestamp']),
                            style: TextStyle(
                              color: Colors.grey[500],
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
  }
}